// Teclas 1..0 de la fila superior y del teclado numérico.
const CODE_TO_INDEX = {
  Digit1: 0, Digit2: 1, Digit3: 2, Digit4: 3, Digit5: 4,
  Digit6: 5, Digit7: 6, Digit8: 7, Digit9: 8, Digit0: 9,
  Numpad1: 0, Numpad2: 1, Numpad3: 2, Numpad4: 3, Numpad5: 4,
  Numpad6: 5, Numpad7: 6, Numpad8: 7, Numpad9: 8, Numpad0: 9,
};

const MODIFIER_KEYS = new Set(["Control", "Alt", "Shift", "Meta"]);

// Último texto insertado por la extensión. Solo se reemplaza si sigue intacto.
let lastInserted = null; // { element, text, start }

function isEditable(el) {
  if (!el) return false;
  if (el.isContentEditable) return true;
  if (el.tagName === "TEXTAREA") return !el.readOnly && !el.disabled;
  if (el.tagName === "INPUT") {
    const type = (el.type || "text").toLowerCase();
    return ["text", "search", "tel", "url", "email"].includes(type) && !el.readOnly && !el.disabled;
  }
  return false;
}

function stillIntact(el) {
  if (!lastInserted || lastInserted.element !== el) return false;
  const { start, text } = lastInserted;
  const end = start + text.length;
  return el.value.substring(start, end) === text && el.selectionStart === end && el.selectionEnd === end;
}

function insertText(el, text) {
  if ((el.tagName === "INPUT" || el.tagName === "TEXTAREA") && el.selectionStart !== null) {
    const replacing = stillIntact(el);
    // Si no es seguro reemplazar, solo se inserta en el cursor y no se borra nada.
    const from = replacing ? lastInserted.start : el.selectionEnd;
    const to = el.selectionEnd;

    el.setRangeText(text, from, to, "end");
    el.dispatchEvent(new Event("input", { bubbles: true }));
    lastInserted = { element: el, text, start: from };
    return;
  }

  // contenteditable y campos sin selección.
  el.focus();
  document.execCommand("insertText", false, text);
  lastInserted = null;
}

document.addEventListener("keydown", (event) => {
  const index = CODE_TO_INDEX[event.code];

  // Alt + número (sin Ctrl ni Meta, para no chocar con atajos de Brave).
  if (event.altKey && !event.ctrlKey && !event.metaKey && index !== undefined) {
    const el = document.activeElement;
    if (!isEditable(el)) return; // fuera de un campo: la tecla sigue su curso normal

    event.preventDefault();
    event.stopPropagation();

    chrome.storage.local.get({ codes: [] }, ({ codes }) => {
      const text = (codes[index] || "").trim();
      if (text && isEditable(el)) insertText(el, text);
    });
    return;
  }

  // Cualquier otra tecla puede cambiar el texto o el cursor. Las modificadoras solas no.
  if (!MODIFIER_KEYS.has(event.key)) lastInserted = null;
}, true);

// Si el usuario escribe, pega o borra, el reemplazo ya no es seguro.
document.addEventListener("input", (event) => {
  if (event.isTrusted) lastInserted = null;
}, true);

// Un clic puede mover el cursor.
document.addEventListener("mousedown", () => { lastInserted = null; }, true);
