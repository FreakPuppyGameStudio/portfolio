const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];
const rowsEl = document.getElementById("rows");
const statusEl = document.getElementById("status");

KEYS.forEach((key, i) => {
  const row = document.createElement("div");
  row.className = "row";

  const label = document.createElement("span");
  label.className = "key";
  label.textContent = key;

  const input = document.createElement("input");
  input.id = `code-${i}`;
  input.maxLength = 200;
  input.placeholder = "Vacío";

  row.append(label, input);
  rowsEl.appendChild(row);
});

chrome.storage.local.get({ codes: [] }, ({ codes }) => {
  KEYS.forEach((_, i) => {
    document.getElementById(`code-${i}`).value = codes[i] || "";
  });
});

document.getElementById("save").addEventListener("click", () => {
  const codes = KEYS.map((_, i) => document.getElementById(`code-${i}`).value.trim());
  chrome.storage.local.set({ codes }, () => {
    statusEl.textContent = "Guardado";
    setTimeout(() => (statusEl.textContent = ""), 1500);
  });
});
